<?php include("../../lib/f.php"); ?>
<html>

<head>

<title>Blessed Trust Control Center</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="keywords" content="">
<script type="application/x-javascript"> addEventListener("load", function() {setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<link href="admin/css/style.css" rel='stylesheet' type='text/css' />

<!-- Fonts -->
<link href="//fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
<!-- //Fonts -->
</head>
    
<body>
<p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>
	<h2><i>Blessed Trust <br> Control Center</i></h2>
    <?php er()?>
<br>
    
	<div class="w3layoutscontaineragileits">
        <form action="../lib/ff.php?fm=1" method="post">
			<input type="text" Name="uname" placeholder="USERNAME" required="" id="uname">
			<input type="password" Name="pword" placeholder="PASSWORD" required="" id="pword">
			<ul class="agileinfotickwthree">
				<li>
					<input type="checkbox" id="brand1" value="">
					<label for="brand1"><span></span>Remember me</label>
				</li>
			</ul>
			<div class="aitssendbuttonw3ls">
				<input type="submit" value="LOGIN" onclick="login()">
				<div class="clear"></div>
			</div>
            </form>
	</div>

	
</body>
    <script type="text/javascript" src="jquery-1.7.2.min.js"></script>
    <script type="text/javascript" src="script.js"></script>
<!-- //Body -->

   
</html>